package com.mycompany.ecu911;

import ecu911.controlador.CiudadanoControlador;
import ecu911.controlador.NotaControlador;
import ecu911.modelo.*;
import ecu911.util.RelojSistema;
import ecu911.controlador.OperadorControlador;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Ecu911 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Operador> listaOperadores = new ArrayList<>();
        List<Ciudadano> listaCiudadanos = new ArrayList<>();
        List<Llamada> listaLlamadas = new ArrayList<>();
        List<NotaSeguimiento> listaNotas = new ArrayList<>();

        // Datos iniciales obligatorios (ajusta Turno.MATUTINO y TipoEmergencia.TRANSITO según cómo los escribió tu grupo)
        Operador opInicial = new Operador("Laura", "Mendoza", Turno.MATUTINO, "l.mendoza@ecu911.gob.ec");
        listaOperadores.add(opInicial);

        Ciudadano ciuInicial = new Ciudadano("Marcos Andrés", "Villacís Torres", "0912345678");
        listaCiudadanos.add(ciuInicial);

        Llamada llInicial = new Llamada(opInicial, ciuInicial, TipoEmergencia.TRANSITO, "Guayaquil", "Urdesa", "Choque leve sin heridos");
        listaLlamadas.add(llInicial);
        ciuInicial.agregarLlamada(llInicial);

        NotaSeguimiento notaInicial = new NotaSeguimiento(opInicial, "Unidad de tránsito despachada al sitio.", llInicial);
        listaNotas.add(notaInicial);

        OperadorControlador operadorCtrl =new OperadorControlador(scanner, listaOperadores, listaLlamadas);
        CiudadanoControlador ciudadanoCtrl = new CiudadanoControlador(scanner, listaCiudadanos);
        NotaControlador notaCtrl = new NotaControlador(listaNotas, listaLlamadas, listaOperadores);
        int opcion = 0;
        while (opcion != 5) {
            System.out.println("\nSISTEMA DE REGISTRO DE LLAMADAS ECU 911 (Versión 1.0)");
            System.out.println("[Menú Principal]");
            System.out.println("[1] Administrar llamadas de emergencia");
            System.out.println("[2] Administrar operadores");
            System.out.println("[3] Administrar ciudadanos");
            System.out.println("[4] Administrar notas de seguimiento");
            System.out.println("[5] Salir");
            System.out.println("Fecha y hora actuales del sistema: " + RelojSistema.formatear(RelojSistema.ahora()));
            System.out.print("> Seleccione una opción (1-5): ");

            try {
                opcion = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                opcion = -1;
            }

            switch (opcion) {
            case 1:
                System.out.println("Módulo en construcción...");
                break;

            case 2:
                operadorCtrl.iniciarMenuOperadores();
                break;

            case 3:
                ciudadanoCtrl.iniciarMenuCiudadanos();
                break;

            case 4:
                notaCtrl.iniciarMenuNotas();
                break;

            case 5:
                System.out.println("Cerrando el sistema ECU 911. ¡Hasta pronto!");
                break;

            default:
                System.out.println("¡Error! Opción fuera de rango.");
            }
        }
        scanner.close();
    }
}