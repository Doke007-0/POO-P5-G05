package ecu911.modelo;

/**
 * Representa a un operador del sistema ECU 911.
 */
public class Operador extends Persona {
    private static int contadorOperadores = 1;
    
    private String codigo;
    private Turno turno;
    private String email;

    public Operador(String nombres, String apellidos, Turno turno, String email) {
        super(nombres, apellidos);
        this.codigo = String.format("OP-%02d", contadorOperadores++);
        this.turno = turno;
        this.email = email;
    }
    @Override
    public String getIdentificador() {
        return this.codigo;
    }
    public String getCodigo() { return codigo; }
    public Turno getTurno() { return turno; }
    public void setTurno(Turno turno) { this.turno = turno; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
}